import random, math, time

def count_conflicts(board):
    conflicts = 0
    n = len(board)
    for i in range(n):
        for j in range(i + 1, n):
            if board[i] == board[j] or abs(board[i] - board[j]) == abs(i - j):
                conflicts += 1
    return conflicts

def simulated_annealing_n_queens(n, max_steps=100000, temp=1000, cooling=0.99):
    board = [random.randint(0, n - 1) for _ in range(n)]
    for step in range(max_steps):
        conflicts = count_conflicts(board)
        if conflicts == 0:
            return board
        row = random.randint(0, n - 1)
        new_col = random.randint(0, n - 1)
        new_board = board[:]
        new_board[row] = new_col
        new_conflicts = count_conflicts(new_board)
        delta = new_conflicts - conflicts
        if delta < 0 or random.random() < math.exp(-delta / temp):
            board = new_board
        temp *= cooling
    return None

if __name__ == "__main__":
    n = 100
    start = time.time()
    result = simulated_annealing_n_queens(n)
    end = time.time()
    if result:
        print(f"[Simulated Annealing] Solved for N={n} in {end - start:.2f} seconds.")
    else:
        print(f"[Simulated Annealing] Failed to find solution for N={n}")