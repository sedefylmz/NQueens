import random, time

def count_conflicts(board):
    conflicts = 0
    n = len(board)
    for i in range(n):
        for j in range(i + 1, n):
            if board[i] == board[j] or abs(board[i] - board[j]) == abs(i - j):
                conflicts += 1
    return conflicts

def hill_climb_n_queens(n, max_restarts=1000):
    for _ in range(max_restarts):
        board = [random.randint(0, n - 1) for _ in range(n)]
        steps = 0
        while steps < 1000:
            current_conflicts = count_conflicts(board)
            if current_conflicts == 0:
                return board
            moves = []
            for row in range(n):
                for col in range(n):
                    if board[row] != col:
                        new_board = board[:]
                        new_board[row] = col
                        conflicts = count_conflicts(new_board)
                        if conflicts < current_conflicts:
                            moves.append((conflicts, new_board))
            if not moves:
                break
            moves.sort()
            board = moves[0][1]
            steps += 1
    return None  # Failed

if __name__ == "__main__":
    n = 50
    start = time.time()
    result = hill_climb_n_queens(n)
    end = time.time()
    if result:
        print(f"[Hill Climbing] Solved for N={n} in {end - start:.2f} seconds.")
    else:
        print(f"[Hill Climbing] Failed to find solution for N={n}")
