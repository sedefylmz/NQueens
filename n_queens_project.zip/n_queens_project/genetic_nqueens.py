import random, time

def count_conflicts(board):
    conflicts = 0
    n = len(board)
    for i in range(n):
        for j in range(i + 1, n):
            if abs(board[i] - board[j]) == abs(i - j):
                conflicts += 1
    return conflicts

def fitness(board):
    n = len(board)
    max_pairs = n * (n - 1) // 2
    return max_pairs - count_conflicts(board)

def crossover(p1, p2):
    n = len(p1)
    point = random.randint(0, n - 1)
    child = p1[:point] + [x for x in p2 if x not in p1[:point]]
    return child

def mutate(board):
    a, b = random.sample(range(len(board)), 2)
    board[a], board[b] = board[b], board[a]

def genetic_n_queens(n, pop_size=100, generations=1000):
    population = [random.sample(range(n), n) for _ in range(pop_size)]
    for gen in range(generations):
        population.sort(key=lambda x: -fitness(x))
        if fitness(population[0]) == n * (n - 1) // 2:
            return population[0]
        next_gen = population[:10]  # elitism
        while len(next_gen) < pop_size:
            p1, p2 = random.choices(population[:50], k=2)
            child = crossover(p1, p2)
            if random.random() < 0.3:
                mutate(child)
            next_gen.append(child)
        population = next_gen
    return None

if __name__ == "__main__":
    n = 100
    start = time.time()
    result = genetic_n_queens(n)
    end = time.time()
    if result:
        print(f"[Genetic Algorithm] Solved for N={n} in {end - start:.2f} seconds.")
    else:
        print(f"[Genetic Algorithm] Failed to find solution for N={n}")
