def solve_n_queens(n):
    def is_safe(board, row, col):
        for i in range(row):
            if board[i] == col or \
               abs(board[i] - col) == abs(i - row):
                return False
        return True

    def dfs(row, board, solutions):
        if row == n:
            solutions.append(board[:])
            return
        for col in range(n):
            if is_safe(board, row, col):
                board[row] = col
                dfs(row + 1, board, solutions)

    solutions = []
    board = [-1] * n
    dfs(0, board, solutions)
    return solutions

# Test for small N
from time import time
start = time()
solutions = solve_n_queens(8)
end = time()
print(f"Found {len(solutions)} solutions in {end - start:.2f} seconds.")

